
    

    <!-- Page -->
    <div class="page">
      <div class="page-content container-fluid">
       

        <div class="panel">
            <header class="panel-heading">
                <h3 class="panel-title">Akun</h3> 
                <div class="panel-actions panel-actions-keep">
                    <button type="button" id="tambahakun" class="btn btn-block btn-success"><i class="icon md-plus" aria-hidden="true"></i>Tambah</button>
                </div>
            </header>
            <div class="panel-body">
                <table class="table table-hover dataTable table-striped w-full" id="akun">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Status</th>
                            <th width="100px">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    </tbody>
                </table>
            </div>
        </div>
          
          
    
    </div>
    </div>
    <!-- End Page -->


    
