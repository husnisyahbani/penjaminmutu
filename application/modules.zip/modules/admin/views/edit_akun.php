


<!-- Page -->
<div class="page">
    <div class="page-content container-fluid">

        <div class="row">
            <div class="col-lg-12">

                <div class="panel">
                    <div class="panel-heading">
                        <h3 class="panel-title">Akun </h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" id="formaddakun" autocomplete="off" action="<?php echo base_url() . 'admin/akun/edit?id='.$result[0]['users_id'];?>" method="post" enctype="multipart/form-data">

                            

                            <div class="form-group row">
                                <label class="col-md-3 form-control-label">Username</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="username" value="<?php if (isset($result[0]['username'])) echo $result[0]['username']; ?>"/>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-3 form-control-label">Password</label>
                                <div class="col-md-9">
                                    <input type="password" class="form-control" name="password" value="<?php if (isset($result[0]['password'])) echo $result[0]['password']; ?>"/>
                                </div>
                            </div>
                            
                            <div class="form-group row">
                                <label class="col-md-3 form-control-label">Role</label>
                                <div class="col-md-9">
                                    <select class="form-control" name="role" id="role">
                                        <option value="">-- Pilih Peran --</option>
                                        <option value="ADMIN" <?php if (isset($result[0]['role']) && $result[0]['role'] === "ADMIN") {echo "selected";} ?>>ADMIN</option>
                                        </select>
                                </div>
                            </div>   

                            <div class="text-right">
                                <button type="submit" class="btn btn-primary" id="validateButton" name="submitakun">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- End Panel Wizard Form Container -->
            </div>
        </div> 


    </div>
</div>
<!-- End Page -->






