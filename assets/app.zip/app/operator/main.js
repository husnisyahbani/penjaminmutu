/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(function () {

    $('#alokasi').DataTable({
        "responsive": true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "columnDefs": [
            {"targets": [0,5], "orderable": false}
        ],
        "ajax": {
            "url": base_url + "/main/listalokasi",
            "type": "POST"
        }
    });

    $("#tambah").on("click", function () {
        window.open(base_url + "operatora/news/tambah");
    });
    
    $("#tambahoffer").on("click", function () {
        window.open(base_url + "operatora/offers/tambah");
    });
    
    $("#tambahhotel").on("click", function () {
        window.open(base_url + "operatora/hotel/tambah");
    });
    
    $("#tambahkepala").on("click", function () {
        window.open(base_url + "operatora/kepala/tambah");
    });
    
    $('#formpassword').formValidation({
        framework: "bootstrap4",
        button: {
            selector: '#validateButton',
            disabled: 'disabled'
        },
        icon: null,
        fields: {
            
            passlama: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            }, password: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            }, repassword: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            }

        },
        err: {
            clazz: 'invalid-feedback'
        },
        control: {
            // The CSS class for valid control
            valid: 'is-valid',
            // The CSS class for invalid control
            invalid: 'is-invalid'
        },
        row: {
            invalid: 'has-danger'
        }
    });

    
});


