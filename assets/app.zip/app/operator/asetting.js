$(function () {

    $('#aindex').DataTable({
        "responsive": true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "columnDefs": [
            {"targets": [0,3], "orderable": false}
        ],
        "ajax": {
            "url": base_url + "/asetting/listasetting",
            "type": "POST"
        }
    });


    $('#mapping').DataTable({
        "responsive": true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "columnDefs": [
            {"targets": [0,4], "orderable": false}
        ],
        "ajax": {
            "url": base_url + "/asetting/listasettingmapping",
            "type": "POST"
        }
    });

    $("#aindex").on("click", ".delete", function () {
        var id = $(this).attr('id');
        hapusaindex(id);
    });

    $("#aindex").on("click", ".edit", function () {
        var id = $(this).attr('id');
        location.href = base_url+ "/asetting/edit?id="+id;
    });

    $("#mapping").on("click", ".delete", function () {
        var id = $(this).attr('id');
        hapusarekap(id);
    });

    $("#mapping").on("click", ".edit", function () {
        var id = $(this).attr('id');
        location.href = base_url+ "/asetting/editarekap?id="+id;
    });



    $("#tambahaindex").on("click", function () {
        //window.open(base_url + "/pegawai/tambah");
        location.href = base_url + "/asetting/tambah";
    });

    $("#tambahmapping").on("click", function () {
        //window.open(base_url + "/pegawai/tambah");
        location.href = base_url + "/asetting/tambaharekap";
    });

    function hapusarekap($id)
    {
        swal.fire({
            title: "Anda Yakin?",
            text: "Anda Yakin Ingin Data Ini?",
            type: "warning",
            showCancelButton: true,
            showLoaderOnConfirm: true,
            confirmButtonText: "Ya, Hapus!",
            cancelButtonText: 'Tidak',
            preConfirm: function () {
                $.ajax({
                    url: base_url + "/asetting/hapusarekap",
                    type: "POST",
                    data: { id: $id}
                })
                        .done(function (data) {
                            swal.fire({
                                title: "Hapus",
                                text: "Data Telah Terhapus!",
                                type: "success",
                                preConfirm: function () {
                                    location.href = base_url + "/asetting";
                                }
                            });
                        })
                        .error(function (data) {
                            swal.fire("Oops", "No connection!", "error");
                        });
            }
        });
    }

    function hapusaindex($id)
    {
        swal.fire({
            title: "Anda Yakin?",
            text: "Anda Yakin Ingin Menghapus Jabatan Ini?",
            type: "warning",
            showCancelButton: true,
            showLoaderOnConfirm: true,
            confirmButtonText: "Ya, Hapus!",
            cancelButtonText: 'Tidak',
            preConfirm: function () {
                $.ajax({
                    url: base_url + "/asetting/hapus",
                    type: "POST",
                    data: { id: $id}
                })
                        .done(function (data) {
                            swal.fire({
                                title: "Hapus",
                                text: "Data Telah Terhapus!",
                                type: "success",
                                preConfirm: function () {
                                    location.href = base_url + "/asetting";
                                }
                            });
                        })
                        .error(function (data) {
                            swal.fire("Oops", "No connection!", "error");
                        });
            }
        });
    }

    


    $('#formaddasetting').formValidation({
        framework: "bootstrap4",
        button: {
            selector: '#validateButton',
            disabled: 'disabled'
        },
        icon: null,
        fields: {
            
           
            adx_jabatan: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            },
            adx_index: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            }

        },
        err: {
            clazz: 'invalid-feedback'
        },
        control: {
            // The CSS class for valid control
            valid: 'is-valid',
            // The CSS class for invalid control
            invalid: 'is-invalid'
        },
        row: {
            invalid: 'has-danger'
        }
    });


    $('#formeditcsetting').formValidation({
        framework: "bootstrap4",
        button: {
            selector: '#validateButton',
            disabled: 'disabled'
        },
        icon: null,
        fields: {
            
           
            obj_nama: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            }

        },
        err: {
            clazz: 'invalid-feedback'
        },
        control: {
            // The CSS class for valid control
            valid: 'is-valid',
            // The CSS class for invalid control
            invalid: 'is-invalid'
        },
        row: {
            invalid: 'has-danger'
        }
    });

    $("#uploadarekap").on("click", function () {
        $('#settingModal').modal('show');       
    });
})