$(function () {

    $('#arekap').DataTable({
        "responsive": true,
        "processing": true,
        "serverSide": true,
        "searching": true,
        "order": [],
        "columnDefs": [
            {"targets": [0,4,5], "orderable": false}
        ],
        "ajax": {
            "url": base_url + "/arekap/listarekap",
            "type": "POST"
        }
    });

    $("#downloadarekap").on("click", function () {
        location.href = base_url + "/arekap/downloadarekap";
    });

    $("#tambaharekap").on("click", function () {
        location.href = base_url + "/arekap/tambah";
    });

    $("#arekap").on("click", ".delete", function () {
        var id = $(this).attr('id');
        hapusarekap(id);
    });


    function hapusarekap($id)
    {
        swal.fire({
            title: "Anda Yakin?",
            text: "Anda Yakin Ingin Data Ini?",
            type: "warning",
            showCancelButton: true,
            showLoaderOnConfirm: true,
            confirmButtonText: "Ya, Hapus!",
            cancelButtonText: 'Tidak',
            preConfirm: function () {
                $.ajax({
                    url: base_url + "/arekap/hapusarekap",
                    type: "POST",
                    data: { id: $id}
                })
                        .done(function (data) {
                            swal.fire({
                                title: "Hapus",
                                text: "Data Telah Terhapus!",
                                type: "success",
                                preConfirm: function () {
                                    location.href = base_url + "/arekap";
                                }
                            });
                        })
                        .error(function (data) {
                            swal.fire("Oops", "No connection!", "error");
                        });
            }
        });
    }


    $('#formaddkelompoka').formValidation({
        framework: "bootstrap4",
        button: {
            selector: '#validateButton',
            disabled: 'disabled'
        },
        icon: null,
        fields: {
            
           
            alokasi: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            },bulan: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            },
            tahun: {
                validators: {
                    notEmpty: {
                        message: 'Wajib Diisi'
                    }
                }
            }
        },
        err: {
            clazz: 'invalid-feedback'
        },
        control: {
            // The CSS class for valid control
            valid: 'is-valid',
            // The CSS class for invalid control
            invalid: 'is-invalid'
        },
        row: {
            invalid: 'has-danger'
        }
    });

})